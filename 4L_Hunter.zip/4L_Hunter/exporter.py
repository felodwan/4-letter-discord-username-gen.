"""TXT / CSV export helpers."""
from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from database import Row


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def export_available_txt(rows: list[Row], directory: Path | str) -> Path:
    """Write one AVAILABLE username per line; returns the file path."""
    from checker import Status

    out_dir = Path(directory)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"available_{_stamp()}.txt"
    names = [r.username for r in rows if r.status is Status.AVAILABLE]
    path.write_text("\n".join(names) + ("\n" if names else ""), encoding="utf-8")
    return path


def export_all_csv(rows: list[Row], directory: Path | str) -> Path:
    """Write every result to CSV (UTF-8 with BOM so Excel opens it cleanly)."""
    out_dir = Path(directory)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"results_{_stamp()}.csv"
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.writer(fh)
        writer.writerow(["username", "status", "verified_at", "source", "note"])
        for r in rows:
            writer.writerow([r.username, r.status.value, r.checked_at, r.source, r.note])
    return path


def export_names_txt(names: list[str], directory: Path | str, prefix: str = "generated") -> Path:
    """Write an arbitrary list of usernames (one per line)."""
    out_dir = Path(directory)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{prefix}_{_stamp()}.txt"
    path.write_text("\n".join(names) + ("\n" if names else ""), encoding="utf-8")
    return path
