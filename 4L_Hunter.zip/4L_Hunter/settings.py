"""Persistent user settings (JSON file in the per-user data directory)."""
from __future__ import annotations

import json
import os
import sys
import tempfile
from dataclasses import asdict, dataclass, fields
from pathlib import Path

APP_NAME = "4L Hunter"
APP_VERSION = "1.0.0"


def data_dir() -> Path:
    """Per-user data directory (override with FOURL_HUNTER_HOME for tests)."""
    override = os.environ.get("FOURL_HUNTER_HOME")
    if override:
        base = Path(override)
    elif sys.platform.startswith("win"):
        base = Path(os.environ.get("APPDATA", Path.home())) / "4L Hunter"
    else:
        base = Path.home() / ".4l_hunter"
    base.mkdir(parents=True, exist_ok=True)
    return base


def default_export_dir() -> str:
    docs = Path.home() / "Documents"
    return str((docs if docs.is_dir() else Path.home()) / "4L Hunter Exports")


@dataclass
class Settings:
    theme: str = "dark"                 # "dark" | "light"
    generation_count: int = 100         # 10, 50, 100, 500, 1000
    mode: str = "Letters only"
    prevent_duplicates: bool = True
    avoid_obvious: bool = False
    export_dir: str = ""
    # Safe request settings (used by any automatic provider)
    request_delay: float = 2.0          # seconds between requests (minimum 1.0)
    request_timeout: float = 10.0       # seconds per request (1-60)
    max_requests_per_run: int = 50      # hard cap per run (1-500)

    def sanitize(self) -> "Settings":
        """Clamp every value into a safe range; never raises."""
        if self.theme not in ("dark", "light"):
            self.theme = "dark"
        if self.generation_count not in (10, 50, 100, 500, 1000):
            self.generation_count = 100
        self.prevent_duplicates = bool(self.prevent_duplicates)
        self.avoid_obvious = bool(self.avoid_obvious)
        if not isinstance(self.export_dir, str) or not self.export_dir:
            self.export_dir = default_export_dir()
        self.request_delay = _clamp(self.request_delay, 1.0, 60.0, 2.0)
        self.request_timeout = _clamp(self.request_timeout, 1.0, 60.0, 10.0)
        self.max_requests_per_run = int(_clamp(self.max_requests_per_run, 1, 500, 50))
        if not isinstance(self.mode, str):
            self.mode = "Letters only"
        return self


def _clamp(value: object, lo: float, hi: float, default: float) -> float:
    try:
        v = float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return default
    if v != v:  # NaN
        return default
    return max(lo, min(hi, v))


class SettingsStore:
    """Loads/saves Settings atomically; a corrupt file falls back to defaults."""

    def __init__(self, path: Path | None = None) -> None:
        self.path = path or (data_dir() / "settings.json")

    def load(self) -> Settings:
        known = {f.name for f in fields(Settings)}
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                raise ValueError("settings root must be an object")
            return Settings(**{k: v for k, v in raw.items() if k in known}).sanitize()
        except FileNotFoundError:
            return Settings().sanitize()
        except (OSError, ValueError, TypeError):
            # Keep the broken file for inspection, then start fresh.
            try:
                self.path.replace(self.path.with_suffix(".json.bad"))
            except OSError:
                pass
            return Settings().sanitize()

    def save(self, settings: Settings) -> None:
        settings.sanitize()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=self.path.parent, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(asdict(settings), fh, indent=2)
            os.replace(tmp, self.path)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)
