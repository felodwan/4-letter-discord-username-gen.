"""Main window: sidebar navigation + stacked pages."""
from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QApplication, QButtonGroup, QFrame, QHBoxLayout, QLabel, QMainWindow, QPushButton,
    QStackedWidget, QVBoxLayout, QWidget,
)

from settings import APP_NAME, APP_VERSION
from theme import stylesheet
from ui_pages import AppContext, GeneratorPage, PatternPage, ResultsPage, SettingsPage


def resource_path(rel: str) -> Path:
    """Locate bundled assets both from source and from a PyInstaller bundle."""
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base / rel


class MainWindow(QMainWindow):
    def __init__(self, ctx: AppContext) -> None:
        super().__init__()
        self.ctx = ctx
        self.setWindowTitle("4L HUNTER")
        self.resize(1120, 720)
        self.setMinimumSize(900, 600)
        icon = resource_path("assets/icon.ico")
        if icon.exists():
            self.setWindowIcon(QIcon(str(icon)))

        root = QWidget()
        root.setObjectName("root")
        self.setCentralWidget(root)
        outer = QHBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        side = QFrame()
        side.setObjectName("sidebar")
        side.setFixedWidth(210)
        sl = QVBoxLayout(side)
        sl.setContentsMargins(14, 22, 14, 16)
        sl.setSpacing(4)
        title = QLabel("4L HUNTER")
        title.setObjectName("title")
        sub = QLabel("Username generator")
        sub.setObjectName("muted")
        sl.addWidget(title)
        sl.addWidget(sub)
        sl.addSpacing(22)

        self.stack = QStackedWidget()
        self.results = ResultsPage(ctx)
        pages = [("Generator", GeneratorPage(ctx)), ("Custom pattern", PatternPage(ctx)),
                 ("Results", self.results), ("Settings", SettingsPage(ctx))]
        group = QButtonGroup(self)
        group.setExclusive(True)
        for i, (name, page) in enumerate(pages):
            self.stack.addWidget(page)
            b = QPushButton(name)
            b.setObjectName("nav")
            b.setCheckable(True)
            group.addButton(b)
            b.clicked.connect(lambda _=False, idx=i: self.stack.setCurrentIndex(idx))
            sl.addWidget(b)
            if i == 0:
                b.setChecked(True)
        sl.addStretch(1)
        ver = QLabel(f"v{APP_VERSION}")
        ver.setObjectName("muted")
        sl.addWidget(ver)

        outer.addWidget(side)
        outer.addWidget(self.stack, 1)
        ctx.message.connect(lambda t: self.statusBar().showMessage(t, 8000))
        ctx.theme_changed.connect(self.apply_theme)
        self.apply_theme(ctx.settings.theme)

    def apply_theme(self, theme: str) -> None:
        app = QApplication.instance()
        if isinstance(app, QApplication):
            app.setStyleSheet(stylesheet(theme))
