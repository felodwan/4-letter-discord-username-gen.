"""SQLite storage for generated candidates and their verification status."""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from checker import Status
from settings import data_dir


@dataclass(frozen=True)
class Row:
    username: str
    status: Status
    checked_at: str   # ISO-8601 local time, seconds precision
    source: str       # "generated" | "manual" | "api" | "validation"
    note: str = ""


def now_iso() -> str:
    return datetime.now().replace(microsecond=0).isoformat(sep=" ")


class Database:
    def __init__(self, path: Path | str | None = None) -> None:
        self.path = str(path or (data_dir() / "results.db"))
        self._conn = sqlite3.connect(self.path)
        self._conn.execute(
            """CREATE TABLE IF NOT EXISTS results (
                   username   TEXT PRIMARY KEY,
                   status     TEXT NOT NULL,
                   checked_at TEXT NOT NULL,
                   source     TEXT NOT NULL,
                   note       TEXT NOT NULL DEFAULT ''
               )"""
        )
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    def upsert(self, row: Row) -> None:
        self._conn.execute(
            "INSERT INTO results VALUES (?,?,?,?,?) ON CONFLICT(username) DO UPDATE SET "
            "status=excluded.status, checked_at=excluded.checked_at, "
            "source=excluded.source, note=excluded.note",
            (row.username, row.status.value, row.checked_at, row.source, row.note),
        )
        self._conn.commit()

    def insert_new(self, rows: list[Row]) -> int:
        """Insert rows, ignoring usernames that already exist. Returns rows added."""
        before = self.count()
        self._conn.executemany(
            "INSERT OR IGNORE INTO results VALUES (?,?,?,?,?)",
            [(r.username, r.status.value, r.checked_at, r.source, r.note) for r in rows],
        )
        self._conn.commit()
        return self.count() - before

    def all(self) -> list[Row]:
        cur = self._conn.execute(
            "SELECT username,status,checked_at,source,note FROM results ORDER BY rowid"
        )
        return [Row(u, Status(s), c, src, n) for u, s, c, src, n in cur.fetchall()]

    def usernames(self) -> set[str]:
        return {r[0] for r in self._conn.execute("SELECT username FROM results")}

    def count(self) -> int:
        return int(self._conn.execute("SELECT COUNT(*) FROM results").fetchone()[0])

    def counts_by_status(self) -> dict[Status, int]:
        out = {s: 0 for s in Status}
        for status, n in self._conn.execute("SELECT status, COUNT(*) FROM results GROUP BY status"):
            out[Status(status)] = n
        return out

    def delete(self, usernames: list[str]) -> None:
        self._conn.executemany("DELETE FROM results WHERE username=?", [(u,) for u in usernames])
        self._conn.commit()

    def clear(self) -> None:
        self._conn.execute("DELETE FROM results")
        self._conn.commit()
