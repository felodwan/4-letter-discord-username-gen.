@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Building 4L Hunter

echo ============================================================
echo   4L HUNTER - Windows build
echo ============================================================

REM ---- 1. Find a suitable Python (3.11+) ---------------------------------
set "PY="
where py >nul 2>nul && (py -3 -c "import sys; sys.exit(0 if sys.version_info>=(3,11) else 1)" >nul 2>nul && set "PY=py -3")
if not defined PY (
    where python >nul 2>nul && (python -c "import sys; sys.exit(0 if sys.version_info>=(3,11) else 1)" >nul 2>nul && set "PY=python")
)
if not defined PY (
    echo [ERROR] Python 3.11 or newer was not found.
    echo         Install it from https://www.python.org/downloads/ and tick "Add python.exe to PATH",
    echo         then run build.bat again.
    goto :fail
)
echo [1/6] Using Python:
%PY% --version
if errorlevel 1 goto :fail

REM ---- 2. Virtual environment ---------------------------------------------
if not exist ".venv\Scripts\python.exe" (
    echo [2/6] Creating virtual environment...
    %PY% -m venv .venv
    if errorlevel 1 goto :fail
) else (
    echo [2/6] Reusing existing virtual environment.
)
set "VPY=.venv\Scripts\python.exe"

REM ---- 3. Dependencies -----------------------------------------------------
echo [3/6] Installing dependencies...
"%VPY%" -m pip install --upgrade pip
if errorlevel 1 goto :fail
"%VPY%" -m pip install -r requirements.txt
if errorlevel 1 goto :fail

REM ---- 4. PyInstaller ------------------------------------------------------
echo [4/6] Installing PyInstaller...
"%VPY%" -m pip install --upgrade pyinstaller
if errorlevel 1 goto :fail

REM ---- 5. Compile ----------------------------------------------------------
echo [5/6] Compiling executable (this can take a few minutes)...
set "ICON_ARG="
set "DATA_ARG="
if exist "assets\icon.ico" (
    set "ICON_ARG=--icon assets\icon.ico"
    set "DATA_ARG=--add-data assets;assets"
) else (
    echo [WARN] assets\icon.ico not found - building without a custom icon.
)
if exist "dist\4L Hunter.exe" del /q "dist\4L Hunter.exe"
"%VPY%" -m PyInstaller --noconfirm --clean --onefile --windowed --name "4L Hunter" %ICON_ARG% %DATA_ARG% --paths . main.py
if errorlevel 1 goto :fail

REM ---- 6. Verify -----------------------------------------------------------
if not exist "dist\4L Hunter.exe" (
    echo [ERROR] Build finished but dist\4L Hunter.exe was not created.
    goto :fail
)
echo [6/6] Done.
echo.
echo   SUCCESS:  %~dp0dist\4L Hunter.exe
echo.
pause
exit /b 0

:fail
echo.
echo   BUILD FAILED - see the messages above.
echo.
pause
exit /b 1
