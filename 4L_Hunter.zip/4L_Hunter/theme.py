"""Dark / light stylesheets (black + dark grey with subtle blue accents)."""
from __future__ import annotations

PALETTES = {
    "dark": dict(
        bg="#0b0c0f", panel="#14161b", panel2="#1b1e25", border="#262a33",
        text="#e6e8ec", muted="#8b92a1", accent="#3b82f6", accent_hover="#5b9bff",
        accent_text="#ffffff", input="#0f1115", select="#1d3a6b",
        available="#34d399", taken="#f87171", unknown="#fbbf24", invalid="#8b92a1",
    ),
    "light": dict(
        bg="#f3f4f7", panel="#ffffff", panel2="#eceef3", border="#d6d9e0",
        text="#16181d", muted="#5b6272", accent="#2563eb", accent_hover="#3b82f6",
        accent_text="#ffffff", input="#ffffff", select="#cfe0ff",
        available="#059669", taken="#dc2626", unknown="#b45309", invalid="#6b7280",
    ),
}


def palette(theme: str) -> dict[str, str]:
    return PALETTES.get(theme, PALETTES["dark"])


def stylesheet(theme: str) -> str:
    p = palette(theme)
    return f"""
* {{ font-family: "Segoe UI", "Inter", "Helvetica Neue", Arial, sans-serif; font-size: 13px; }}
QMainWindow, QDialog, QWidget#root {{ background: {p['bg']}; color: {p['text']}; }}
QWidget {{ color: {p['text']}; }}
QLabel {{ background: transparent; }}
QLabel#title {{ font-size: 22px; font-weight: 700; letter-spacing: 3px; }}
QLabel#h1 {{ font-size: 18px; font-weight: 600; }}
QLabel#muted {{ color: {p['muted']}; }}
QLabel#bigName {{ font-size: 40px; font-weight: 700; letter-spacing: 4px; color: {p['accent']}; }}
QFrame#sidebar {{ background: {p['panel']}; border-right: 1px solid {p['border']}; }}
QFrame#card {{ background: {p['panel']}; border: 1px solid {p['border']}; border-radius: 12px; }}
QPushButton {{
    background: {p['panel2']}; border: 1px solid {p['border']}; border-radius: 8px;
    padding: 8px 12px; color: {p['text']};
}}
QPushButton:hover {{ border-color: {p['accent']}; }}
QPushButton:disabled {{ color: {p['muted']}; background: {p['panel']}; }}
QPushButton#primary {{
    background: {p['accent']}; border: 1px solid {p['accent']}; color: {p['accent_text']}; font-weight: 600;
}}
QPushButton#primary:hover {{ background: {p['accent_hover']}; }}
QPushButton#primary:disabled {{ background: {p['panel2']}; border-color: {p['border']}; color: {p['muted']}; }}
QPushButton#nav {{
    text-align: left; padding: 11px 16px; border: none; border-radius: 8px; background: transparent;
    color: {p['muted']}; font-weight: 500;
}}
QPushButton#nav:hover {{ background: {p['panel2']}; color: {p['text']}; }}
QPushButton#nav:checked {{ background: {p['panel2']}; color: {p['accent']}; border-left: 3px solid {p['accent']}; }}
QPushButton#chip {{ border-radius: 14px; padding: 6px 14px; background: {p['panel2']}; }}
QPushButton#chip:checked {{ background: {p['accent']}; color: {p['accent_text']}; border-color: {p['accent']}; }}
QPushButton#rowcopy {{ padding: 3px 10px; border-radius: 6px; }}
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QPlainTextEdit {{
    background: {p['input']}; border: 1px solid {p['border']}; border-radius: 8px; padding: 7px 10px;
    selection-background-color: {p['select']}; selection-color: {p['text']};
}}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus {{ border-color: {p['accent']}; }}
QComboBox QAbstractItemView {{
    background: {p['panel']}; border: 1px solid {p['border']}; selection-background-color: {p['select']};
    color: {p['text']};
}}
QCheckBox {{ spacing: 8px; background: transparent; }}
QCheckBox::indicator {{ width: 16px; height: 16px; border-radius: 4px; border: 1px solid {p['border']}; background: {p['input']}; }}
QCheckBox::indicator:checked {{ background: {p['accent']}; border-color: {p['accent']}; }}
QTableWidget {{
    background: {p['panel']}; alternate-background-color: {p['panel2']}; border: 1px solid {p['border']};
    border-radius: 10px; gridline-color: transparent; selection-background-color: {p['select']};
    selection-color: {p['text']};
}}
QHeaderView::section {{
    background: {p['panel2']}; color: {p['muted']}; border: none; padding: 8px; font-weight: 600;
}}
QScrollBar:vertical {{ background: transparent; width: 10px; }}
QScrollBar::handle:vertical {{ background: {p['border']}; border-radius: 5px; min-height: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; }}
QScrollBar::handle:horizontal {{ background: {p['border']}; border-radius: 5px; min-width: 30px; }}
QProgressBar {{ background: {p['panel2']}; border: none; border-radius: 4px; height: 8px; text-align: center; }}
QProgressBar::chunk {{ background: {p['accent']}; border-radius: 4px; }}
QToolTip {{ background: {p['panel2']}; color: {p['text']}; border: 1px solid {p['border']}; padding: 4px; }}
QMessageBox {{ background: {p['panel']}; }}
"""
