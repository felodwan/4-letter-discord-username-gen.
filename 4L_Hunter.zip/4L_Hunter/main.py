"""4L Hunter - entry point."""
from __future__ import annotations

import sys

from PySide6.QtWidgets import QApplication, QMessageBox

from checker import AvailabilityChecker
from database import Database
from settings import APP_NAME, SettingsStore
from ui_main import MainWindow
from ui_pages import AppContext


def build_context() -> AppContext:
    store = SettingsStore()
    settings = store.load()
    checker = AvailabilityChecker(
        timeout=settings.request_timeout,
        delay=settings.request_delay,
        max_requests=settings.max_requests_per_run,
    )
    return AppContext(store, settings, Database(), checker)


def main(argv: list[str]) -> int:
    app = QApplication(argv)
    app.setApplicationName(APP_NAME)
    try:
        ctx = build_context()
    except Exception as exc:  # e.g. unwritable data directory
        QMessageBox.critical(None, APP_NAME, f"Could not start:\n{exc}")
        return 1
    window = MainWindow(ctx)
    window.show()
    if "--selftest" in argv:  # used to verify a packaged build starts correctly
        from PySide6.QtCore import QTimer
        QTimer.singleShot(500, app.quit)
    code = app.exec()
    ctx.db.close()
    return code


if __name__ == "__main__":
    sys.exit(main(sys.argv))
