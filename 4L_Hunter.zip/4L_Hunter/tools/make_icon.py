"""Regenerates assets/icon.ico (developer tool; needs `pip install pillow`)."""
import glob
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

size = 256
img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
d = ImageDraw.Draw(img)
d.rounded_rectangle((8, 8, size - 8, size - 8), radius=56, fill=(11, 12, 15, 255),
                    outline=(59, 130, 246, 255), width=8)
fonts = glob.glob("C:/Windows/Fonts/segoeuib.ttf") or glob.glob("/usr/share/fonts/**/*Bold*.ttf", recursive=True)
font = ImageFont.truetype(fonts[0], 120) if fonts else ImageFont.load_default()
d.text((size / 2, size / 2 - 6), "4L", font=font, fill=(59, 130, 246, 255), anchor="mm")
d.rounded_rectangle((70, 196, 186, 204), radius=4, fill=(230, 232, 236, 255))
out = Path(__file__).resolve().parent.parent / "assets" / "icon.ico"
img.save(out, sizes=[(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (16, 16)])
print("wrote", out)
