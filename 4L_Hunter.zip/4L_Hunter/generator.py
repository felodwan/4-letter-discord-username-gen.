"""Candidate generation and Discord username format validation.

Discord's documented username rules (https://discord.com/developers/docs/resources/user):
  * 2-32 characters
  * only lowercase letters (a-z), digits (0-9), underscores (_) and periods (.)
  * no two consecutive periods
This app additionally requires exactly four characters.
"""
from __future__ import annotations

import itertools
import random
import re
import string
from dataclasses import dataclass, field
from enum import Enum

USERNAME_LENGTH = 4
LETTERS = string.ascii_lowercase
DIGITS = string.digits
ALLOWED_CHARS = frozenset(LETTERS + DIGITS + "_.")
_USERNAME_RE = re.compile(r"^[a-z0-9_.]{2,32}$")

# If the whole search space is at most this large we enumerate it, which lets us
# sample *without* replacement and guarantees we never loop forever.
_ENUMERATE_LIMIT = 600_000
_rng = random.SystemRandom()  # OS-level randomness: hard to predict


class Mode(str, Enum):
    LETTERS = "Letters only"
    ALNUM = "Numbers and letters"
    UNDERSCORE = "Letters with underscores"
    PERIOD = "Letters with periods"
    CUSTOM = "Custom characters"


class GeneratorError(ValueError):
    """Raised for invalid generator input (shown to the user as-is)."""


def validate_username(name: str, length: int = USERNAME_LENGTH) -> tuple[bool, str]:
    """Return (is_valid, reason). Reason is empty when valid."""
    if len(name) != length:
        return False, f"Must be exactly {length} characters (got {len(name)})"
    if not _USERNAME_RE.match(name):
        return False, "Only lowercase a-z, 0-9, '_' and '.' are allowed"
    if ".." in name:
        return False, "Two consecutive periods are not allowed"
    return True, ""


def expand_charset(spec: str) -> str:
    """Expand a character-set expression such as ``a-f0-9_.`` into unique chars.

    Ranges (``a-z``) are supported; a '-' at the start or end is a literal dash
    (which Discord does not allow, so it will be rejected later). Input is
    lower-cased because Discord usernames are lowercase.
    """
    spec = spec.strip().lower().replace(" ", "")
    out: list[str] = []
    i = 0
    while i < len(spec):
        if i + 2 < len(spec) and spec[i + 1] == "-":
            lo, hi = spec[i], spec[i + 2]
            if ord(lo) > ord(hi):
                raise GeneratorError(f"Invalid range '{lo}-{hi}'")
            out.extend(chr(c) for c in range(ord(lo), ord(hi) + 1))
            i += 3
        else:
            out.append(spec[i])
            i += 1
    seen: dict[str, None] = dict.fromkeys(out)
    return "".join(seen)


def is_obvious(name: str) -> bool:
    """Heuristic for easily guessed patterns: aaaa, abab, aabb, abcd, dcba, 1234."""
    if len(name) != 4:
        return False
    a, b, c, d = name
    if a == b == c == d:
        return True
    if (a == c and b == d) or (a == b and c == d):
        return True
    codes = [ord(x) for x in name]
    steps = {codes[i + 1] - codes[i] for i in range(3)}
    return steps in ({1}, {-1})


@dataclass
class GeneratorConfig:
    mode: Mode = Mode.LETTERS
    count: int = 100
    prefix: str = ""
    exclude: str = ""
    custom_chars: str = ""
    prevent_duplicates: bool = True
    avoid_obvious: bool = False
    skip: set[str] = field(default_factory=set)  # names to never return (already in results)


def charset_for(mode: Mode, custom_chars: str = "") -> tuple[str, str]:
    """Return (pool, required_special). ``required_special`` chars must appear >= once."""
    if mode is Mode.LETTERS:
        return LETTERS, ""
    if mode is Mode.ALNUM:
        return LETTERS + DIGITS, ""
    if mode is Mode.UNDERSCORE:
        return LETTERS + "_", "_"
    if mode is Mode.PERIOD:
        return LETTERS + ".", "."
    pool = expand_charset(custom_chars)
    if not pool:
        raise GeneratorError("Enter at least one custom character")
    return pool, ""


def _build_positions(cfg: GeneratorConfig) -> list[str]:
    """Allowed characters for each of the four positions."""
    pool, _ = charset_for(cfg.mode, cfg.custom_chars)
    excluded = set(expand_charset(cfg.exclude)) if cfg.exclude else set()
    pool = "".join(c for c in pool if c not in excluded and c in ALLOWED_CHARS)
    prefix = cfg.prefix.strip().lower()
    if len(prefix) > USERNAME_LENGTH:
        raise GeneratorError(f"Starting characters can be at most {USERNAME_LENGTH}")
    for ch in prefix:
        if ch not in ALLOWED_CHARS:
            raise GeneratorError(f"Starting character '{ch}' is not allowed by Discord")
        if ch in excluded:
            raise GeneratorError(f"Starting character '{ch}' is also in the exclude list")
    if not pool and len(prefix) < USERNAME_LENGTH:
        raise GeneratorError("No characters left to generate with after exclusions")
    return [prefix[i] if i < len(prefix) else pool for i in range(USERNAME_LENGTH)]


def _space_size(positions: list[str]) -> int:
    n = 1
    for p in positions:
        n *= len(p)
    return n


def generate_from_positions(
    positions: list[str],
    count: int,
    *,
    required_special: str = "",
    prevent_duplicates: bool = True,
    avoid_obvious: bool = False,
    skip: set[str] | None = None,
) -> list[str]:
    """Core sampler: draw ``count`` valid usernames from per-position character sets.

    Returns fewer than ``count`` only when the space is exhausted; raises
    GeneratorError if nothing at all can be produced.
    """
    if len(positions) != USERNAME_LENGTH or any(not p for p in positions):
        raise GeneratorError("Every position needs at least one allowed character")
    if count < 1:
        raise GeneratorError("Count must be at least 1")
    skip = skip or set()

    def acceptable(name: str) -> bool:
        if not validate_username(name)[0]:
            return False
        if required_special and required_special not in name:
            return False
        if avoid_obvious and is_obvious(name):
            return False
        return name not in skip

    results: list[str] = []
    if prevent_duplicates and _space_size(positions) <= _ENUMERATE_LIMIT:
        pool = [n for n in map("".join, itertools.product(*positions)) if acceptable(n)]
        if not pool:
            raise GeneratorError("No valid usernames exist for these settings")
        return _rng.sample(pool, min(count, len(pool)))

    seen: set[str] = set()
    attempts, max_attempts = 0, count * 60 + 5000
    while len(results) < count and attempts < max_attempts:
        attempts += 1
        name = "".join(_rng.choice(p) for p in positions)
        if not acceptable(name):
            continue
        if prevent_duplicates:
            if name in seen:
                continue
            seen.add(name)
        results.append(name)
    if not results:
        raise GeneratorError("Could not generate valid usernames with these settings")
    return results


def generate(cfg: GeneratorConfig) -> list[str]:
    """Generate usernames for one of the standard modes."""
    positions = _build_positions(cfg)
    _, special = charset_for(cfg.mode, cfg.custom_chars)
    if special and special in set(cfg.exclude):
        raise GeneratorError(f"'{special}' is required by this mode but is excluded")
    return generate_from_positions(
        positions,
        cfg.count,
        required_special=special,
        prevent_duplicates=cfg.prevent_duplicates,
        avoid_obvious=cfg.avoid_obvious,
        skip=cfg.skip,
    )


def generate_pattern(
    position_specs: list[str],
    count: int,
    *,
    prevent_duplicates: bool = True,
    avoid_obvious: bool = False,
    skip: set[str] | None = None,
) -> list[str]:
    """Custom pattern generator: one character-set expression per position.

    Example: ``["a-z", "0-9", "_.", "a-z0-9"]`` -> candidates like ``q9_x``.
    A single literal such as ``"q"`` pins a position.
    """
    if len(position_specs) != USERNAME_LENGTH:
        raise GeneratorError(f"Exactly {USERNAME_LENGTH} positions are required")
    positions: list[str] = []
    for i, spec in enumerate(position_specs, start=1):
        chars = "".join(c for c in expand_charset(spec) if c in ALLOWED_CHARS)
        if not chars:
            raise GeneratorError(f"Position {i} has no valid characters")
        positions.append(chars)
    return generate_from_positions(
        positions,
        count,
        prevent_duplicates=prevent_duplicates,
        avoid_obvious=avoid_obvious,
        skip=skip,
    )
