"""Availability checker.

IMPORTANT - what this module does and does not do
-------------------------------------------------
Discord does not publish an official, supported API for checking whether a
username is free. This app therefore does NOT guess at undocumented endpoints.
The default provider (``ManualProvider``) reports every well-formed candidate as
UNKNOWN and the UI offers a manual verification workflow instead.

For the future (if Discord ever documents such an endpoint) the module contains
the safe plumbing a real provider needs: ``SafeHttpClient`` (timeouts, HTTP
error mapping, 429/Retry-After handling) and ``HttpProvider`` (subclass it and
implement ``build_request`` / ``interpret``). Nothing here ever returns
AVAILABLE unless a provider explicitly returns a definitive API answer.
"""
from __future__ import annotations

import json
import socket
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Callable, Protocol

from generator import validate_username


class Status(str, Enum):
    AVAILABLE = "AVAILABLE"
    TAKEN = "TAKEN"
    UNKNOWN = "UNKNOWN"
    INVALID = "INVALID"


@dataclass(frozen=True)
class CheckResult:
    username: str
    status: Status
    checked_at: str
    source: str   # "validation" | "manual" | "api"
    note: str = ""


def _now() -> str:
    return datetime.now().replace(microsecond=0).isoformat(sep=" ")


def make_result(username: str, status: Status, source: str, note: str = "") -> CheckResult:
    return CheckResult(username, status, _now(), source, note)


# ----------------------------------------------------------------- errors ---
class CheckError(Exception):
    """Base class: the lookup failed, which must never be read as 'available'."""


class NetworkFailure(CheckError):
    """Connection problem or timeout."""


class HttpFailure(CheckError):
    def __init__(self, status: int, message: str = "") -> None:
        super().__init__(f"HTTP {status} {message}".strip())
        self.status = status


class RateLimited(CheckError):
    def __init__(self, retry_after: float) -> None:
        super().__init__(f"Rate limited; retry after {retry_after:.0f}s")
        self.retry_after = retry_after


# ------------------------------------------------------------ HTTP client ---
@dataclass
class HttpResponse:
    status: int
    body: bytes

    def json(self) -> object:
        return json.loads(self.body.decode("utf-8"))


class SafeHttpClient:
    """Minimal urllib wrapper with a hard timeout and strict error mapping."""

    def __init__(self, timeout: float = 10.0, user_agent: str = "4LHunter/1.0") -> None:
        self.timeout = timeout
        self.user_agent = user_agent

    def request(self, req: urllib.request.Request) -> HttpResponse:
        req.add_header("User-Agent", self.user_agent)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:  # noqa: S310
                return HttpResponse(resp.status, resp.read(1_000_000))
        except urllib.error.HTTPError as exc:
            if exc.code == 429:
                raise RateLimited(_retry_after(exc)) from exc
            if exc.code in (200, 404):  # 404 may be a meaningful answer; let provider decide
                return HttpResponse(exc.code, exc.read(1_000_000))
            raise HttpFailure(exc.code, str(exc.reason)) from exc
        except (urllib.error.URLError, socket.timeout, TimeoutError, ConnectionError, OSError) as exc:
            raise NetworkFailure(str(getattr(exc, "reason", exc))) from exc


def _retry_after(exc: urllib.error.HTTPError) -> float:
    try:
        return max(1.0, min(float(exc.headers.get("Retry-After", "30")), 3600.0))
    except (TypeError, ValueError):
        return 30.0


# -------------------------------------------------------------- providers ---
class AvailabilityProvider(Protocol):
    name: str
    supports_automatic: bool

    def check(self, username: str, client: SafeHttpClient) -> CheckResult: ...


class ManualProvider:
    """Default: no supported automatic method exists, so nothing is guessed."""

    name = "Manual verification"
    supports_automatic = False

    def check(self, username: str, client: SafeHttpClient) -> CheckResult:
        return make_result(
            username, Status.UNKNOWN, "validation",
            "No officially supported availability API - verify manually",
        )


class HttpProvider:
    """Base class for a future *officially documented* availability endpoint."""

    name = "HTTP provider"
    supports_automatic = True

    def build_request(self, username: str) -> urllib.request.Request:
        raise NotImplementedError

    def interpret(self, username: str, response: HttpResponse) -> CheckResult:
        """Return a definitive AVAILABLE/TAKEN result, or UNKNOWN if unsure."""
        raise NotImplementedError

    def check(self, username: str, client: SafeHttpClient) -> CheckResult:
        return self.interpret(username, client.request(self.build_request(username)))


# ---------------------------------------------------------------- checker ---
class AvailabilityChecker:
    """Validates, then delegates to a provider with failures mapped to UNKNOWN."""

    def __init__(
        self,
        provider: AvailabilityProvider | None = None,
        *,
        timeout: float = 10.0,
        delay: float = 2.0,
        max_requests: int = 50,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self.provider: AvailabilityProvider = provider or ManualProvider()
        self.client = SafeHttpClient(timeout)
        self.delay = max(1.0, delay)
        self.max_requests = max(1, max_requests)
        self._sleep = sleep

    @property
    def automatic_available(self) -> bool:
        return self.provider.supports_automatic

    def status_text(self) -> str:
        if self.automatic_available:
            return f"Automatic checks via {self.provider.name}"
        return "Automatic checker unavailable (no supported Discord API) - use manual verification"

    def check(self, username: str) -> CheckResult:
        ok, reason = validate_username(username)
        if not ok:
            return make_result(username, Status.INVALID, "validation", reason)
        try:
            result = self.provider.check(username, self.client)
        except RateLimited:
            raise
        except CheckError as exc:
            return make_result(username, Status.UNKNOWN, "api", f"Check failed: {exc}")
        except Exception as exc:  # defensive: a buggy provider must not crash the app
            return make_result(username, Status.UNKNOWN, "api", f"Unexpected error: {exc}")
        # Safety net: only trust AVAILABLE from a provider that can really check.
        if result.status is Status.AVAILABLE and not self.provider.supports_automatic:
            return make_result(username, Status.UNKNOWN, "validation", "Unverified result rejected")
        return result

    def check_many(
        self,
        usernames: list[str],
        on_result: Callable[[CheckResult], None] | None = None,
        should_stop: Callable[[], bool] = lambda: False,
    ) -> list[CheckResult]:
        """Check sequentially with a delay; stops on rate limit or request cap."""
        results: list[CheckResult] = []
        requests_made = 0
        for i, name in enumerate(usernames):
            if should_stop():
                break
            valid = validate_username(name)[0]
            if valid:
                if requests_made >= self.max_requests:
                    break
                if requests_made:
                    self._sleep(self.delay)
                requests_made += 1
            try:
                res = self.check(name)
            except RateLimited as exc:
                res = make_result(name, Status.UNKNOWN, "api", str(exc))
                results.append(res)
                if on_result:
                    on_result(res)
                break  # never hammer a rate-limited service
            results.append(res)
            if on_result:
                on_result(res)
        return results
