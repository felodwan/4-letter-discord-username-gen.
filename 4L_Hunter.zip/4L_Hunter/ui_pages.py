"""All GUI pages and dialogs for 4L Hunter."""
from __future__ import annotations

import webbrowser
from pathlib import Path

from PySide6.QtCore import QObject, Qt, QThread, Signal
from PySide6.QtGui import QColor, QGuiApplication, QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QAbstractItemView, QButtonGroup, QCheckBox, QComboBox, QDialog, QDoubleSpinBox,
    QFileDialog, QFrame, QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QMessageBox, QPlainTextEdit, QProgressBar, QPushButton, QSpinBox, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget,
)

import exporter
import generator
from checker import AvailabilityChecker, CheckResult, Status
from database import Database, Row, now_iso
from generator import GeneratorConfig, GeneratorError, Mode
from settings import APP_NAME, APP_VERSION, Settings, SettingsStore
from theme import palette

COUNTS = [10, 50, 100, 500, 1000]


# --------------------------------------------------------------- context ---
class AppContext(QObject):
    """Shared state + signals so pages stay decoupled."""

    results_changed = Signal()
    theme_changed = Signal(str)
    message = Signal(str)

    def __init__(self, store: SettingsStore, settings: Settings, db: Database,
                 checker: AvailabilityChecker) -> None:
        super().__init__()
        self.store, self.settings, self.db, self.checker = store, settings, db, checker

    def save_settings(self) -> None:
        try:
            self.store.save(self.settings)
        except OSError as exc:
            self.message.emit(f"Could not save settings: {exc}")
        self.checker.delay = self.settings.request_delay
        self.checker.client.timeout = self.settings.request_timeout
        self.checker.max_requests = self.settings.max_requests_per_run

    def add_candidates(self, names: list[str], note: str = "Not yet verified") -> int:
        """Store candidates: format-invalid ones become INVALID, the rest UNKNOWN."""
        stamp = now_iso()
        rows: list[Row] = []
        for n in names:
            ok, reason = generator.validate_username(n)
            rows.append(Row(n, Status.UNKNOWN if ok else Status.INVALID, stamp,
                            "generated" if ok else "validation", note if ok else reason))
        added = self.db.insert_new(rows)
        self.results_changed.emit()
        return added

    def copy(self, text: str) -> None:
        QGuiApplication.clipboard().setText(text)


def _card() -> QFrame:
    f = QFrame()
    f.setObjectName("card")
    return f


def _label(text: str, name: str = "") -> QLabel:
    lb = QLabel(text)
    if name:
        lb.setObjectName(name)
    return lb


def _warn(parent: QWidget, text: str) -> None:
    QMessageBox.warning(parent, APP_NAME, text)


# ------------------------------------------------------------ check worker ---
class CheckWorker(QThread):
    """Runs AvailabilityChecker.check_many off the GUI thread."""

    result = Signal(object)
    done = Signal(int)

    def __init__(self, checker: AvailabilityChecker, names: list[str]) -> None:
        super().__init__()
        self._checker, self._names, self._stop = checker, names, False

    def stop(self) -> None:
        self._stop = True

    def run(self) -> None:
        res = self._checker.check_many(self._names, self.result.emit, lambda: self._stop)
        self.done.emit(len(res))


# ---------------------------------------------------------- generator page ---
class GeneratorPage(QWidget):
    def __init__(self, ctx: AppContext) -> None:
        super().__init__()
        self.ctx = ctx
        self.last_batch: list[str] = []
        self.worker: CheckWorker | None = None
        s = ctx.settings

        root = QVBoxLayout(self)
        root.setContentsMargins(28, 24, 28, 24)
        root.setSpacing(14)
        root.addWidget(_label("Generator", "h1"))
        root.addWidget(_label("Create unique four-character candidates, validated against Discord's "
                              "username format rules.", "muted"))

        body = QHBoxLayout()
        body.setSpacing(14)
        root.addLayout(body, 1)

        # Left: options
        opts = _card()
        grid = QGridLayout(opts)
        grid.setContentsMargins(18, 18, 18, 18)
        grid.setVerticalSpacing(10)
        grid.setColumnStretch(1, 1)

        self.mode = QComboBox()
        self.mode.addItems([m.value for m in Mode])
        self.mode.setCurrentText(s.mode if s.mode in [m.value for m in Mode] else Mode.LETTERS.value)
        self.count = QComboBox()
        self.count.addItems([str(c) for c in COUNTS])
        self.count.setCurrentText(str(s.generation_count))
        self.prefix = QLineEdit()
        self.prefix.setMaxLength(generator.USERNAME_LENGTH)
        self.prefix.setPlaceholderText("optional, e.g. q9")
        self.exclude = QLineEdit()
        self.exclude.setPlaceholderText("characters to avoid, e.g. 0o1il")
        self.custom = QLineEdit()
        self.custom.setPlaceholderText("e.g. a-f0-9_.  (ranges allowed)")
        self.nodup = QCheckBox("Prevent duplicates (also skips names already in Results)")
        self.nodup.setChecked(s.prevent_duplicates)
        self.noobvious = QCheckBox("Avoid obvious patterns (aaaa, abab, abcd, 1234)")
        self.noobvious.setChecked(s.avoid_obvious)

        rows = [("Mode", self.mode), ("Candidates", self.count), ("Starting characters", self.prefix),
                ("Exclude characters", self.exclude), ("Custom characters", self.custom)]
        for i, (text, w) in enumerate(rows):
            grid.addWidget(_label(text, "muted"), i, 0)
            grid.addWidget(w, i, 1)
        grid.addWidget(self.nodup, len(rows), 0, 1, 2)
        grid.addWidget(self.noobvious, len(rows) + 1, 0, 1, 2)

        self.gen_btn = QPushButton("Generate")
        self.gen_btn.setObjectName("primary")
        self.gen_btn.setMinimumHeight(40)
        grid.addWidget(self.gen_btn, len(rows) + 2, 0, 1, 2)
        grid.setRowStretch(len(rows) + 3, 1)
        body.addWidget(opts, 0)

        # Right: preview + checking
        right = _card()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(18, 18, 18, 18)
        top = QHBoxLayout()
        self.summary = _label("No candidates generated yet", "muted")
        top.addWidget(self.summary, 1)
        self.save_btn = QPushButton("Save list (TXT)")
        self.copy_btn = QPushButton("Copy list")
        top.addWidget(self.copy_btn)
        top.addWidget(self.save_btn)
        rl.addLayout(top)
        self.preview = QPlainTextEdit()
        self.preview.setReadOnly(True)
        self.preview.setPlaceholderText("Generated usernames appear here and are added to Results as UNKNOWN.")
        rl.addWidget(self.preview, 1)

        self.checker_label = _label(ctx.checker.status_text(), "muted")
        self.checker_label.setWordWrap(True)
        rl.addWidget(self.checker_label)
        self.progress = QProgressBar()
        self.progress.setTextVisible(False)
        self.progress.setVisible(False)
        rl.addWidget(self.progress)
        btns = QHBoxLayout()
        self.auto_btn = QPushButton("Run automatic check")
        self.auto_btn.setEnabled(ctx.checker.automatic_available)
        self.auto_btn.setToolTip("Disabled: Discord offers no officially supported availability API."
                                 if not ctx.checker.automatic_available else "Check all UNKNOWN names")
        self.manual_btn = QPushButton("Verify manually...")
        self.manual_btn.setObjectName("primary")
        btns.addWidget(self.auto_btn)
        btns.addWidget(self.manual_btn)
        rl.addLayout(btns)
        body.addWidget(right, 1)

        self.mode.currentTextChanged.connect(self._mode_changed)
        self._mode_changed(self.mode.currentText())
        self.gen_btn.clicked.connect(self.generate)
        self.save_btn.clicked.connect(self.save_list)
        self.copy_btn.clicked.connect(lambda: self.last_batch and ctx.copy("\n".join(self.last_batch)))
        self.auto_btn.clicked.connect(self.run_auto)
        self.manual_btn.clicked.connect(self.open_manual)

    def _mode_changed(self, text: str) -> None:
        self.custom.setEnabled(text == Mode.CUSTOM.value)

    def config(self) -> GeneratorConfig:
        return GeneratorConfig(
            mode=Mode(self.mode.currentText()), count=int(self.count.currentText()),
            prefix=self.prefix.text(), exclude=self.exclude.text(), custom_chars=self.custom.text(),
            prevent_duplicates=self.nodup.isChecked(), avoid_obvious=self.noobvious.isChecked(),
            skip=self.ctx.db.usernames() if self.nodup.isChecked() else set(),
        )

    def generate(self) -> None:
        try:
            cfg = self.config()
            names = generator.generate(cfg)
        except GeneratorError as exc:
            _warn(self, str(exc))
            return
        s = self.ctx.settings
        s.mode, s.generation_count = cfg.mode.value, cfg.count
        s.prevent_duplicates, s.avoid_obvious = cfg.prevent_duplicates, cfg.avoid_obvious
        self.ctx.save_settings()
        self.last_batch = names
        added = self.ctx.add_candidates(names)
        self.preview.setPlainText("\n".join(names))
        note = "" if len(names) == cfg.count else f" (only {len(names)} possible)"
        self.summary.setText(f"{len(names)} generated{note}  |  {added} new")
        self.ctx.message.emit(f"Generated {len(names)} candidates")

    def save_list(self) -> None:
        if not self.last_batch:
            _warn(self, "Generate some candidates first.")
            return
        try:
            path = exporter.export_names_txt(self.last_batch, self.ctx.settings.export_dir)
        except OSError as exc:
            _warn(self, f"Could not save file:\n{exc}")
            return
        self.ctx.message.emit(f"Saved {path}")

    def open_manual(self) -> None:
        ManualVerifyDialog(self.ctx, self).exec()

    def run_auto(self) -> None:
        names = [r.username for r in self.ctx.db.all() if r.status is Status.UNKNOWN]
        if not names or self.worker is not None:
            return
        self.progress.setRange(0, 0)
        self.progress.setVisible(True)
        self.auto_btn.setEnabled(False)
        self.worker = CheckWorker(self.ctx.checker, names)
        self.worker.result.connect(self._on_result)
        self.worker.done.connect(self._on_done)
        self.worker.start()

    def _on_result(self, res: CheckResult) -> None:
        self.ctx.db.upsert(Row(res.username, res.status, res.checked_at, res.source, res.note))
        self.ctx.results_changed.emit()

    def _on_done(self, n: int) -> None:
        if self.worker:
            self.worker.wait()
        self.worker = None
        self.progress.setVisible(False)
        self.auto_btn.setEnabled(self.ctx.checker.automatic_available)
        self.ctx.message.emit(f"Automatic check finished ({n} processed)")


# ------------------------------------------------------------ pattern page ---
PRESETS = {
    "Letters, digit, letters": ["a-z", "0-9", "a-z", "a-z"],
    "Underscore in position 3 (like sl_z)": ["a-z", "a-z", "_", "a-z"],
    "Period in position 2 (like q.z9)": ["a-z", ".", "a-z", "0-9"],
    "Fully alphanumeric": ["a-z0-9"] * 4,
    "Pinned first letter 'q'": ["q", "a-z0-9", "a-z0-9", "a-z0-9"],
}


class PatternPage(QWidget):
    def __init__(self, ctx: AppContext) -> None:
        super().__init__()
        self.ctx = ctx
        self.last_batch: list[str] = []
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 24, 28, 24)
        root.setSpacing(14)
        root.addWidget(_label("Custom pattern", "h1"))
        root.addWidget(_label("Define the allowed characters for each of the four positions. Use ranges "
                              "like a-z or 0-9, or literals like q. Examples: q9vx, xjrw, sl_z, q.z9", "muted"))

        card = _card()
        g = QGridLayout(card)
        g.setContentsMargins(18, 18, 18, 18)
        g.setHorizontalSpacing(10)
        g.setVerticalSpacing(8)
        self.fields: list[QLineEdit] = []
        for i in range(4):
            g.addWidget(_label(f"Position {i + 1}", "muted"), 0, i)
            e = QLineEdit()
            e.setAlignment(Qt.AlignmentFlag.AlignCenter)
            e.textChanged.connect(self._update_space)
            self.fields.append(e)
            g.addWidget(e, 1, i)
        self.preset = QComboBox()
        self.preset.addItems(PRESETS.keys())
        self.count = QComboBox()
        self.count.addItems([str(c) for c in COUNTS])
        self.count.setCurrentText(str(ctx.settings.generation_count))
        self.nodup = QCheckBox("Prevent duplicates")
        self.nodup.setChecked(ctx.settings.prevent_duplicates)
        self.noobvious = QCheckBox("Avoid obvious patterns")
        self.noobvious.setChecked(ctx.settings.avoid_obvious)
        g.addWidget(_label("Preset", "muted"), 2, 0)
        g.addWidget(self.preset, 2, 1, 1, 3)
        g.addWidget(_label("Candidates", "muted"), 3, 0)
        g.addWidget(self.count, 3, 1, 1, 3)
        g.addWidget(self.nodup, 4, 0, 1, 2)
        g.addWidget(self.noobvious, 4, 2, 1, 2)
        self.space = _label("", "muted")
        g.addWidget(self.space, 5, 0, 1, 4)
        self.gen_btn = QPushButton("Generate from pattern")
        self.gen_btn.setObjectName("primary")
        self.gen_btn.setMinimumHeight(40)
        g.addWidget(self.gen_btn, 6, 0, 1, 4)
        root.addWidget(card)

        out = _card()
        ol = QVBoxLayout(out)
        ol.setContentsMargins(18, 18, 18, 18)
        head = QHBoxLayout()
        self.summary = _label("No results yet", "muted")
        head.addWidget(self.summary, 1)
        self.copy_btn = QPushButton("Copy list")
        head.addWidget(self.copy_btn)
        ol.addLayout(head)
        self.preview = QPlainTextEdit()
        self.preview.setReadOnly(True)
        ol.addWidget(self.preview, 1)
        root.addWidget(out, 1)

        self.preset.currentTextChanged.connect(self._apply_preset)
        self.gen_btn.clicked.connect(self.generate)
        self.copy_btn.clicked.connect(lambda: self.last_batch and ctx.copy("\n".join(self.last_batch)))
        self._apply_preset(self.preset.currentText())

    def _apply_preset(self, name: str) -> None:
        for e, spec in zip(self.fields, PRESETS[name]):
            e.setText(spec)

    def specs(self) -> list[str]:
        return [e.text() for e in self.fields]

    def _update_space(self) -> None:
        try:
            sizes = [len([c for c in generator.expand_charset(t) if c in generator.ALLOWED_CHARS])
                     for t in self.specs()]
        except GeneratorError as exc:
            self.space.setText(str(exc))
            return
        total = 1
        for n in sizes:
            total *= n
        self.space.setText(f"Search space: {total:,} combinations ({' x '.join(map(str, sizes))})")

    def generate(self) -> None:
        count = int(self.count.currentText())
        try:
            names = generator.generate_pattern(
                self.specs(), count, prevent_duplicates=self.nodup.isChecked(),
                avoid_obvious=self.noobvious.isChecked(),
                skip=self.ctx.db.usernames() if self.nodup.isChecked() else set())
        except GeneratorError as exc:
            _warn(self, str(exc))
            return
        self.last_batch = names
        added = self.ctx.add_candidates(names, "Pattern candidate, not yet verified")
        self.preview.setPlainText("\n".join(names))
        note = "" if len(names) == count else f" (only {len(names)} possible)"
        self.summary.setText(f"{len(names)} generated{note}  |  {added} new")
        self.ctx.message.emit(f"Generated {len(names)} pattern candidates")


# ------------------------------------------------------------ results page ---
class ResultsPage(QWidget):
    HEADERS = ["Username", "Status", "Verified at", "Source", ""]

    def __init__(self, ctx: AppContext) -> None:
        super().__init__()
        self.ctx = ctx
        self.filter_status: Status | None = None

        root = QVBoxLayout(self)
        root.setContentsMargins(28, 24, 28, 24)
        root.setSpacing(12)
        root.addWidget(_label("Results", "h1"))

        chips = QHBoxLayout()
        self.group = QButtonGroup(self)
        self.group.setExclusive(True)
        self.chips: dict[Status | None, QPushButton] = {}
        for key in (None, Status.AVAILABLE, Status.TAKEN, Status.UNKNOWN, Status.INVALID):
            b = QPushButton()
            b.setObjectName("chip")
            b.setCheckable(True)
            self.group.addButton(b)
            self.chips[key] = b
            b.clicked.connect(lambda _=False, k=key: self._set_filter(k))
            chips.addWidget(b)
        self.chips[None].setChecked(True)
        chips.addStretch(1)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search usernames...")
        self.search.setClearButtonEnabled(True)
        self.search.setMinimumWidth(170)
        chips.addWidget(self.search)
        root.addLayout(chips)

        self.table = QTableWidget(0, len(self.HEADERS))
        self.table.setHorizontalHeaderLabels(self.HEADERS)
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(False)
        self.table.verticalHeader().setDefaultSectionSize(32)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for c in (1, 2, 3, 4):
            hh.setSectionResizeMode(c, QHeaderView.ResizeMode.ResizeToContents)
        root.addWidget(self.table, 1)

        bar = QHBoxLayout()
        self.btn_copy_sel = QPushButton("Copy selected")
        self.btn_copy_av = QPushButton("Copy available")
        self.btn_copy_av.setToolTip("Copy all AVAILABLE usernames")
        self.btn_txt = QPushButton("Export TXT")
        self.btn_txt.setToolTip("Export AVAILABLE usernames to a TXT file")
        self.btn_csv = QPushButton("Export CSV")
        self.btn_csv.setToolTip("Export all results to a CSV file")
        self.btn_verify = QPushButton("Verify...")
        self.btn_verify.setToolTip("Manual verification workflow")
        self.btn_verify.setObjectName("primary")
        self.btn_del = QPushButton("Delete")
        self.btn_del.setToolTip("Delete selected rows")
        self.btn_clear = QPushButton("Clear")
        self.btn_clear.setToolTip("Clear all results")
        for b in (self.btn_copy_sel, self.btn_copy_av, self.btn_txt, self.btn_csv):
            bar.addWidget(b)
        bar.addStretch(1)
        for b in (self.btn_verify, self.btn_del, self.btn_clear):
            bar.addWidget(b)
        root.addLayout(bar)

        self.search.textChanged.connect(self.refresh)
        self.btn_copy_sel.clicked.connect(self.copy_selected)
        self.btn_copy_av.clicked.connect(self.copy_available)
        self.btn_txt.clicked.connect(self.export_txt)
        self.btn_csv.clicked.connect(self.export_csv)
        self.btn_verify.clicked.connect(lambda: ManualVerifyDialog(ctx, self).exec())
        self.btn_del.clicked.connect(self.delete_selected)
        self.btn_clear.clicked.connect(self.clear)
        self.table.cellDoubleClicked.connect(lambda r, _c: self._copy_row(r))
        ctx.results_changed.connect(self.refresh)
        ctx.theme_changed.connect(lambda _t: self.refresh())
        self.refresh()

    def _set_filter(self, key: Status | None) -> None:
        self.filter_status = key
        self.refresh()

    def _copy_row(self, row: int) -> None:
        item = self.table.item(row, 0)
        if item:
            self.ctx.copy(item.text())
            self.ctx.message.emit(f"Copied {item.text()}")

    def refresh(self) -> None:
        pal = palette(self.ctx.settings.theme)
        colors = {Status.AVAILABLE: pal["available"], Status.TAKEN: pal["taken"],
                  Status.UNKNOWN: pal["unknown"], Status.INVALID: pal["invalid"]}
        counts = self.ctx.db.counts_by_status()
        total = sum(counts.values())
        self.chips[None].setText(f"ALL  {total}")
        for st in Status:
            self.chips[st].setText(f"{st.value}  {counts[st]}")

        needle = self.search.text().strip().lower()
        rows = [r for r in self.ctx.db.all()
                if (self.filter_status is None or r.status is self.filter_status)
                and (not needle or needle in r.username)]
        self.table.setUpdatesEnabled(False)
        self.table.setRowCount(0)  # also discards old cell widgets
        self.table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            name = QTableWidgetItem(r.username)
            f = name.font()
            f.setBold(True)
            f.setFamily("Consolas")
            name.setFont(f)
            st = QTableWidgetItem(r.status.value)
            st.setForeground(QColor(colors[r.status]))
            sf = st.font()
            sf.setBold(True)
            st.setFont(sf)
            src = QTableWidgetItem(r.source)
            src.setToolTip(r.note)
            self.table.setItem(i, 0, name)
            self.table.setItem(i, 1, st)
            self.table.setItem(i, 2, QTableWidgetItem(r.checked_at))
            self.table.setItem(i, 3, src)
            btn = QPushButton("Copy")
            btn.setObjectName("rowcopy")
            btn.clicked.connect(lambda _=False, u=r.username: (self.ctx.copy(u),
                                                               self.ctx.message.emit(f"Copied {u}")))
            self.table.setCellWidget(i, 4, btn)
        self.table.setUpdatesEnabled(True)

    def selected_names(self) -> list[str]:
        rows = sorted({i.row() for i in self.table.selectedIndexes()})
        return [self.table.item(r, 0).text() for r in rows]

    def copy_selected(self) -> None:
        names = self.selected_names()
        if names:
            self.ctx.copy("\n".join(names))
            self.ctx.message.emit(f"Copied {len(names)} usernames")

    def _available(self) -> list[Row]:
        return [r for r in self.ctx.db.all() if r.status is Status.AVAILABLE]

    def copy_available(self) -> None:
        av = self._available()
        if not av:
            QMessageBox.information(self, APP_NAME, "There are no AVAILABLE usernames yet.\n"
                                    "Verify candidates manually first.")
            return
        self.ctx.copy("\n".join(r.username for r in av))
        self.ctx.message.emit(f"Copied {len(av)} available usernames")

    def export_txt(self) -> None:
        av = self._available()
        if not av:
            QMessageBox.information(self, APP_NAME, "There are no AVAILABLE usernames to export.")
            return
        try:
            path = exporter.export_available_txt(av, self.ctx.settings.export_dir)
        except OSError as exc:
            _warn(self, f"Export failed:\n{exc}")
            return
        self.ctx.message.emit(f"Exported {len(av)} usernames to {path}")

    def export_csv(self) -> None:
        rows = self.ctx.db.all()
        if not rows:
            QMessageBox.information(self, APP_NAME, "Nothing to export yet.")
            return
        try:
            path = exporter.export_all_csv(rows, self.ctx.settings.export_dir)
        except OSError as exc:
            _warn(self, f"Export failed:\n{exc}")
            return
        self.ctx.message.emit(f"Exported {len(rows)} rows to {path}")

    def delete_selected(self) -> None:
        names = self.selected_names()
        if names:
            self.ctx.db.delete(names)
            self.refresh()

    def clear(self) -> None:
        if self.ctx.db.count() == 0:
            return
        ans = QMessageBox.question(self, APP_NAME, "Remove ALL results? This cannot be undone.")
        if ans == QMessageBox.StandardButton.Yes:
            self.ctx.db.clear()
            self.refresh()


# ------------------------------------------------------------ manual dialog ---
class ManualVerifyDialog(QDialog):
    """Step through UNKNOWN candidates; the *user* records what Discord told them."""

    def __init__(self, ctx: AppContext, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.ctx = ctx
        self.setWindowTitle("Manual verification")
        self.setMinimumWidth(520)
        self.queue = [r.username for r in ctx.db.all()
                      if r.status is Status.UNKNOWN and generator.validate_username(r.username)[0]]
        self.pos = 0

        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 22, 24, 22)
        lay.setSpacing(12)
        lay.addWidget(_label("Manual verification", "h1"))
        how = _label(
            "1. Open Discord and go to User Settings > My Account > Username > Edit.\n"
            "2. Paste the username below (it is auto-copied) and see whether Discord reports it as "
            "taken.\n3. Record the outcome here. 4L Hunter never contacts Discord for you and never "
            "marks a name AVAILABLE on its own.", "muted")
        how.setWordWrap(True)
        lay.addWidget(how)
        self.counter = _label("", "muted")
        self.counter.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.name = _label("", "bigName")
        self.name.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.name.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        lay.addWidget(self.counter)
        lay.addWidget(self.name)

        tools = QHBoxLayout()
        self.copy_btn = QPushButton("Copy")
        self.open_btn = QPushButton("Open Discord")
        self.autocopy = QCheckBox("Auto-copy each name")
        self.autocopy.setChecked(True)
        tools.addWidget(self.copy_btn)
        tools.addWidget(self.open_btn)
        tools.addStretch(1)
        tools.addWidget(self.autocopy)
        lay.addLayout(tools)

        dec = QHBoxLayout()
        self.avail_btn = QPushButton("Available (A)")
        self.avail_btn.setObjectName("primary")
        self.taken_btn = QPushButton("Taken (T)")
        self.skip_btn = QPushButton("Skip (S)")
        for b in (self.avail_btn, self.taken_btn, self.skip_btn):
            b.setMinimumHeight(38)
            dec.addWidget(b)
        lay.addLayout(dec)
        close = QPushButton("Close")
        lay.addWidget(close, 0, Qt.AlignmentFlag.AlignRight)

        self.copy_btn.clicked.connect(lambda: ctx.copy(self.name.text()))
        self.open_btn.clicked.connect(lambda: webbrowser.open("https://discord.com/app"))
        self.avail_btn.clicked.connect(lambda: self.decide(Status.AVAILABLE))
        self.taken_btn.clicked.connect(lambda: self.decide(Status.TAKEN))
        self.skip_btn.clicked.connect(self.skip)
        close.clicked.connect(self.accept)
        for key, fn in (("A", lambda: self.decide(Status.AVAILABLE)),
                        ("T", lambda: self.decide(Status.TAKEN)), ("S", self.skip)):
            QShortcut(QKeySequence(key), self, activated=fn)
        self._show()

    def _show(self) -> None:
        done = self.pos >= len(self.queue)
        for b in (self.avail_btn, self.taken_btn, self.skip_btn, self.copy_btn):
            b.setEnabled(not done)
        if done:
            self.name.setText("Done" if self.queue else "Nothing to verify")
            self.counter.setText("No UNKNOWN candidates left" if self.queue else "Generate candidates first")
            return
        name = self.queue[self.pos]
        self.name.setText(name)
        self.counter.setText(f"{self.pos + 1} / {len(self.queue)}")
        if self.autocopy.isChecked():
            self.ctx.copy(name)

    def decide(self, status: Status) -> None:
        if self.pos >= len(self.queue):
            return
        name = self.queue[self.pos]
        self.ctx.db.upsert(Row(name, status, now_iso(), "manual", "Confirmed by user in Discord"))
        self.ctx.results_changed.emit()
        self.pos += 1
        self._show()

    def skip(self) -> None:
        if self.pos < len(self.queue):
            self.pos += 1
            self._show()


# ----------------------------------------------------------- settings page ---
class SettingsPage(QWidget):
    def __init__(self, ctx: AppContext) -> None:
        super().__init__()
        self.ctx = ctx
        s = ctx.settings
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 24, 28, 24)
        root.setSpacing(14)
        root.addWidget(_label("Settings", "h1"))

        card = _card()
        g = QGridLayout(card)
        g.setContentsMargins(18, 18, 18, 18)
        g.setVerticalSpacing(10)
        g.setColumnStretch(1, 1)

        self.theme = QComboBox()
        self.theme.addItems(["Dark", "Light"])
        self.theme.setCurrentText(s.theme.capitalize())
        self.count = QComboBox()
        self.count.addItems([str(c) for c in COUNTS])
        self.count.setCurrentText(str(s.generation_count))
        self.nodup = QCheckBox("Prevent duplicate results")
        self.nodup.setChecked(s.prevent_duplicates)
        self.noobvious = QCheckBox("Avoid obvious patterns by default")
        self.noobvious.setChecked(s.avoid_obvious)
        self.export_dir = QLineEdit(s.export_dir)
        browse = QPushButton("Browse...")
        self.delay = QDoubleSpinBox()
        self.delay.setRange(1.0, 60.0)
        self.delay.setSuffix(" s")
        self.delay.setValue(s.request_delay)
        self.timeout = QDoubleSpinBox()
        self.timeout.setRange(1.0, 60.0)
        self.timeout.setSuffix(" s")
        self.timeout.setValue(s.request_timeout)
        self.maxreq = QSpinBox()
        self.maxreq.setRange(1, 500)
        self.maxreq.setValue(s.max_requests_per_run)

        r = 0
        for text, w in (("Theme", self.theme), ("Default generation count", self.count)):
            g.addWidget(_label(text, "muted"), r, 0)
            g.addWidget(w, r, 1, 1, 2)
            r += 1
        g.addWidget(self.nodup, r, 0, 1, 3); r += 1
        g.addWidget(self.noobvious, r, 0, 1, 3); r += 1
        g.addWidget(_label("Export location", "muted"), r, 0)
        g.addWidget(self.export_dir, r, 1)
        g.addWidget(browse, r, 2); r += 1
        g.addWidget(_label("Safe request settings (only used by automatic providers)", "muted"), r, 0, 1, 3); r += 1
        for text, w in (("Delay between requests", self.delay), ("Request timeout", self.timeout),
                        ("Max requests per run", self.maxreq)):
            g.addWidget(_label(text, "muted"), r, 0)
            g.addWidget(w, r, 1, 1, 2)
            r += 1
        root.addWidget(card)
        root.addWidget(_label(f"{APP_NAME}  -  version {APP_VERSION}", "muted"))
        root.addStretch(1)

        browse.clicked.connect(self._browse)
        self.theme.currentTextChanged.connect(self._apply)
        self.count.currentTextChanged.connect(self._apply)
        self.nodup.toggled.connect(self._apply)
        self.noobvious.toggled.connect(self._apply)
        self.export_dir.editingFinished.connect(self._apply)
        self.delay.valueChanged.connect(self._apply)
        self.timeout.valueChanged.connect(self._apply)
        self.maxreq.valueChanged.connect(self._apply)

    def _browse(self) -> None:
        d = QFileDialog.getExistingDirectory(self, "Export location", self.export_dir.text())
        if d:
            self.export_dir.setText(d)
            self._apply()

    def _apply(self, *_: object) -> None:
        s = self.ctx.settings
        old_theme = s.theme
        s.theme = self.theme.currentText().lower()
        s.generation_count = int(self.count.currentText())
        s.prevent_duplicates = self.nodup.isChecked()
        s.avoid_obvious = self.noobvious.isChecked()
        s.export_dir = self.export_dir.text().strip()
        s.request_delay = self.delay.value()
        s.request_timeout = self.timeout.value()
        s.max_requests_per_run = self.maxreq.value()
        self.ctx.save_settings()
        if s.theme != old_theme:
            self.ctx.theme_changed.emit(s.theme)
