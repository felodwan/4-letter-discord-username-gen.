"""Core logic tests (no GUI): generator, checker, database, exporter, settings."""
import csv
import json
import os
import sys
import tempfile
import threading
import unittest
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import checker as ck
import generator as gen
from database import Database, Row, now_iso
from exporter import export_all_csv, export_available_txt, export_names_txt
from settings import Settings, SettingsStore


class GeneratorTests(unittest.TestCase):
    def test_validation(self):
        self.assertTrue(gen.validate_username("q9vx")[0])
        self.assertTrue(gen.validate_username("sl_z")[0])
        self.assertTrue(gen.validate_username("q.z9")[0])
        for bad in ("abc", "abcde", "ABCD", "a..b", "ab-c", "a b ", "ab!c"):
            self.assertFalse(gen.validate_username(bad)[0], bad)

    def _check_all(self, names, n):
        self.assertEqual(len(names), n)
        for x in names:
            self.assertTrue(gen.validate_username(x)[0], x)

    def test_all_modes_and_counts(self):
        for mode in gen.Mode:
            for count in (10, 50, 100, 500, 1000):
                cfg = gen.GeneratorConfig(mode=mode, count=count, custom_chars="a-f0-9_.")
                names = gen.generate(cfg)
                self._check_all(names, count)
                self.assertEqual(len(set(names)), count, "duplicates in " + mode.value)

    def test_mode_character_rules(self):
        letters = gen.generate(gen.GeneratorConfig(mode=gen.Mode.LETTERS, count=200))
        self.assertTrue(all(x.isalpha() for x in letters))
        us = gen.generate(gen.GeneratorConfig(mode=gen.Mode.UNDERSCORE, count=200))
        self.assertTrue(all("_" in x and "." not in x for x in us))
        per = gen.generate(gen.GeneratorConfig(mode=gen.Mode.PERIOD, count=200))
        self.assertTrue(all("." in x and ".." not in x for x in per))
        al = gen.generate(gen.GeneratorConfig(mode=gen.Mode.ALNUM, count=500))
        self.assertTrue(all(x.isalnum() and x.islower() or x.isdigit() or x.isalnum() for x in al))
        self.assertTrue(any(any(c.isdigit() for c in x) for x in al))

    def test_prefix_exclude_custom(self):
        names = gen.generate(gen.GeneratorConfig(mode=gen.Mode.ALNUM, count=100, prefix="q9", exclude="0o1il"))
        self.assertTrue(all(x.startswith("q9") for x in names))
        self.assertTrue(all(not set(x[2:]) & set("0o1il") for x in names))
        names = gen.generate(gen.GeneratorConfig(mode=gen.Mode.CUSTOM, count=50, custom_chars="xyz"))
        self.assertTrue(all(set(x) <= set("xyz") for x in names))

    def test_errors(self):
        with self.assertRaises(gen.GeneratorError):
            gen.generate(gen.GeneratorConfig(prefix="abcde"))
        with self.assertRaises(gen.GeneratorError):
            gen.generate(gen.GeneratorConfig(prefix="A!"))
        with self.assertRaises(gen.GeneratorError):
            gen.generate(gen.GeneratorConfig(prefix="q", exclude="q"))
        with self.assertRaises(gen.GeneratorError):
            gen.generate(gen.GeneratorConfig(mode=gen.Mode.CUSTOM, custom_chars=""))
        with self.assertRaises(gen.GeneratorError):
            gen.generate(gen.GeneratorConfig(mode=gen.Mode.UNDERSCORE, exclude="_"))
        with self.assertRaises(gen.GeneratorError):
            gen.expand_charset("z-a")

    def test_duplicate_prevention_small_space(self):
        # only 2*2*2*2 = 16 combinations: must return exactly 16 unique, not loop forever
        names = gen.generate(gen.GeneratorConfig(mode=gen.Mode.CUSTOM, count=100, custom_chars="ab"))
        self.assertEqual(len(names), 16)
        self.assertEqual(len(set(names)), 16)

    def test_duplicates_allowed(self):
        names = gen.generate(gen.GeneratorConfig(mode=gen.Mode.CUSTOM, count=200, custom_chars="ab",
                                                 prevent_duplicates=False))
        self.assertEqual(len(names), 200)
        self.assertLess(len(set(names)), 200)

    def test_skip_existing(self):
        skip = {"aaab", "aaba"}
        names = gen.generate(gen.GeneratorConfig(mode=gen.Mode.CUSTOM, count=100, custom_chars="ab", skip=skip))
        self.assertFalse(set(names) & skip)
        self.assertEqual(len(names), 14)

    def test_avoid_obvious(self):
        names = gen.generate(gen.GeneratorConfig(mode=gen.Mode.CUSTOM, count=500, custom_chars="abcd",
                                                 avoid_obvious=True))
        self.assertFalse(any(gen.is_obvious(x) for x in names))
        self.assertTrue(gen.is_obvious("aaaa") and gen.is_obvious("abab") and gen.is_obvious("abcd")
                        and gen.is_obvious("4321") and gen.is_obvious("aabb"))
        self.assertFalse(gen.is_obvious("q9vx"))

    def test_expand_charset(self):
        self.assertEqual(gen.expand_charset("a-c"), "abc")
        self.assertEqual(gen.expand_charset("A-C_ ."), "abc_.")
        self.assertEqual(gen.expand_charset("aab"), "ab")
        self.assertEqual(len(gen.expand_charset("a-z0-9_.")), 38)

    def test_patterns(self):
        names = gen.generate_pattern(["a-z", "0-9", "_.", "a-z0-9"], 200)
        self.assertEqual(len(set(names)), 200)
        for x in names:
            self.assertTrue(x[0].isalpha() and x[1].isdigit() and x[2] in "_." and x[3].isalnum(), x)
        names = gen.generate_pattern(["q", "a-z", "_", "z"], 100)
        self.assertEqual(len(names), 26)
        self.assertTrue(all(x.startswith("q") and x[2] == "_" and x.endswith("z") for x in names))
        with self.assertRaises(gen.GeneratorError):  # ".." is never valid -> nothing can be produced
            gen.generate_pattern(["a-z", ".", ".", "a-z"], 10)
        names = gen.generate_pattern(["a-z", ".", "a-z", "0-9"], 50)  # like q.z9
        self.assertTrue(all(x[1] == "." for x in names))

    def test_pattern_errors(self):
        with self.assertRaises(gen.GeneratorError):
            gen.generate_pattern(["a-z"] * 3, 10)
        with self.assertRaises(gen.GeneratorError):
            gen.generate_pattern(["a-z", "", "a", "b"], 10)
        with self.assertRaises(gen.GeneratorError):
            gen.generate_pattern(["a-z", "-", "a", "b"], 10)  # '-' is not an allowed char
        with self.assertRaises(gen.GeneratorError):
            gen.generate_pattern(["a-z"] * 4, 0)


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):  # silence
        pass

    def do_GET(self):
        code = int(self.path.strip("/").split("/")[0].split("?")[0] or 200)
        if code == 200:
            body = json.dumps({"taken": self.path.endswith("taken")}).encode()
            self.send_response(200)
        elif code == 429:
            body = b"slow down"
            self.send_response(429)
            self.send_header("Retry-After", "7")
        else:
            body = b"err"
            self.send_response(code)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


class _MockProvider(ck.HttpProvider):
    """Test-only provider against a local mock server (NOT Discord)."""
    name = "mock"

    def __init__(self, base):
        self.base = base

    def build_request(self, username):
        path = {"takn": "200/taken", "free": "200/free", "boom": "500", "gone": "404", "slow": "429"}.get(username, "200/free")
        return urllib.request.Request(f"{self.base}/{path}")

    def interpret(self, username, response):
        if response.status == 200:
            taken = response.json()["taken"]
            return ck.make_result(username, ck.Status.TAKEN if taken else ck.Status.AVAILABLE, "api")
        return ck.make_result(username, ck.Status.UNKNOWN, "api", f"unexpected {response.status}")


class CheckerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = HTTPServer(("127.0.0.1", 0), _Handler)
        cls.base = f"http://127.0.0.1:{cls.srv.server_port}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def test_manual_provider_never_available(self):
        c = ck.AvailabilityChecker()
        self.assertFalse(c.automatic_available)
        r = c.check("q9vx")
        self.assertEqual(r.status, ck.Status.UNKNOWN)
        self.assertEqual(c.check("ABCD").status, ck.Status.INVALID)
        self.assertEqual(c.check("a..b").status, ck.Status.INVALID)

    def test_rogue_provider_cannot_fake_available(self):
        class Rogue:
            name, supports_automatic = "rogue", False
            def check(self, u, client):
                return ck.make_result(u, ck.Status.AVAILABLE, "api")
        self.assertEqual(ck.AvailabilityChecker(Rogue()).check("abcd").status, ck.Status.UNKNOWN)

    def test_http_provider_results(self):
        c = ck.AvailabilityChecker(_MockProvider(self.base))
        self.assertEqual(c.check("free").status, ck.Status.AVAILABLE)
        self.assertEqual(c.check("takn").status, ck.Status.TAKEN)

    def test_http_error_is_unknown_not_available(self):
        c = ck.AvailabilityChecker(_MockProvider(self.base))
        r = c.check("boom")
        self.assertEqual(r.status, ck.Status.UNKNOWN)
        self.assertIn("500", r.note)
        self.assertEqual(c.check("gone").status, ck.Status.UNKNOWN)

    def test_connection_error_and_timeout(self):
        class Dead(_MockProvider):
            pass
        c = ck.AvailabilityChecker(Dead("http://127.0.0.1:1"), timeout=1)  # nothing listens on port 1
        r = c.check("free")
        self.assertEqual(r.status, ck.Status.UNKNOWN)
        self.assertIn("failed", r.note.lower())

    def test_rate_limit_stops_run(self):
        sleeps = []
        c = ck.AvailabilityChecker(_MockProvider(self.base), sleep=sleeps.append, delay=1.5)
        out = c.check_many(["free", "slow", "takn", "free"])
        self.assertEqual([r.username for r in out], ["free", "slow"])  # stopped at the 429
        self.assertEqual(out[1].status, ck.Status.UNKNOWN)
        self.assertIn("Rate limited", out[1].note)
        self.assertIn("7", out[1].note)
        self.assertEqual(sleeps, [1.5])  # delay between requests honoured

    def test_request_cap_and_stop(self):
        c = ck.AvailabilityChecker(_MockProvider(self.base), sleep=lambda s: None, max_requests=2)
        self.assertEqual(len(c.check_many(["free", "takn", "free", "takn"])), 2)
        c = ck.AvailabilityChecker(_MockProvider(self.base), sleep=lambda s: None)
        self.assertEqual(len(c.check_many(["free", "takn"], should_stop=lambda: True)), 0)

    def test_invalid_names_cost_no_requests(self):
        c = ck.AvailabilityChecker(_MockProvider(self.base), sleep=lambda s: None, max_requests=1)
        out = c.check_many(["BAD!", "free", "BAD2", "takn"])
        self.assertEqual([r.status for r in out][:3], [ck.Status.INVALID, ck.Status.AVAILABLE, ck.Status.INVALID])

    def test_delay_minimum_enforced(self):
        self.assertGreaterEqual(ck.AvailabilityChecker(delay=0.0).delay, 1.0)


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_database(self):
        db = Database(self.dir / "r.db")
        rows = [Row("abcd", ck.Status.UNKNOWN, now_iso(), "generated"), Row("wxyz", ck.Status.UNKNOWN, now_iso(), "generated")]
        self.assertEqual(db.insert_new(rows), 2)
        self.assertEqual(db.insert_new(rows), 0)  # duplicates ignored
        db.upsert(Row("abcd", ck.Status.AVAILABLE, now_iso(), "manual", "ok"))
        counts = db.counts_by_status()
        self.assertEqual(counts[ck.Status.AVAILABLE], 1)
        self.assertEqual(counts[ck.Status.UNKNOWN], 1)
        self.assertEqual(db.usernames(), {"abcd", "wxyz"})
        db.close()
        db = Database(self.dir / "r.db")  # persisted
        self.assertEqual(db.count(), 2)
        db.delete(["abcd"])
        self.assertEqual(db.count(), 1)
        db.clear()
        self.assertEqual(db.count(), 0)

    def test_exports(self):
        rows = [Row("abcd", ck.Status.AVAILABLE, "2026-01-01 10:00:00", "manual"),
                Row("wxyz", ck.Status.TAKEN, "2026-01-01 10:00:01", "manual", "a, b"),
                Row("q9vx", ck.Status.UNKNOWN, "2026-01-01 10:00:02", "generated")]
        out = self.dir / "nested" / "exports"
        txt = export_available_txt(rows, out)
        self.assertEqual(txt.read_text().split(), ["abcd"])
        path = export_all_csv(rows, out)
        with path.open(encoding="utf-8-sig", newline="") as fh:
            data = list(csv.reader(fh))
        self.assertEqual(data[0], ["username", "status", "verified_at", "source", "note"])
        self.assertEqual(len(data), 4)
        self.assertEqual(data[2][4], "a, b")
        self.assertEqual(export_available_txt([], out).read_text(), "")
        self.assertEqual(export_names_txt(["a", "b"], out).read_text(), "a\nb\n")

    def test_settings_persistence_and_robustness(self):
        store = SettingsStore(self.dir / "settings.json")
        s = store.load()
        self.assertEqual(s.theme, "dark")
        s.theme, s.generation_count, s.prevent_duplicates = "light", 500, False
        s.export_dir = str(self.dir / "exp")
        s.request_delay = 5
        store.save(s)
        s2 = SettingsStore(self.dir / "settings.json").load()
        self.assertEqual((s2.theme, s2.generation_count, s2.prevent_duplicates, s2.request_delay), ("light", 500, False, 5.0))
        self.assertEqual(s2.export_dir, str(self.dir / "exp"))
        # out-of-range values get clamped
        (self.dir / "settings.json").write_text(json.dumps(
            {"theme": "pink", "generation_count": 7, "request_delay": 0, "request_timeout": "x",
             "max_requests_per_run": 99999, "unknown_key": 1}))
        s3 = store.load()
        self.assertEqual((s3.theme, s3.generation_count, s3.request_delay, s3.request_timeout, s3.max_requests_per_run),
                         ("dark", 100, 1.0, 10.0, 500))
        # corrupt file -> defaults, original preserved as .bad
        (self.dir / "settings.json").write_text("{not json")
        self.assertEqual(store.load().theme, "dark")
        self.assertTrue((self.dir / "settings.json.bad").exists())


if __name__ == "__main__":
    unittest.main()
