"""GUI smoke tests (run headless with QT_QPA_PLATFORM=offscreen)."""
import os
import sys
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from PySide6.QtCore import QEventLoop, QTimer
from PySide6.QtWidgets import QApplication, QMessageBox

import checker as ck
from checker import AvailabilityChecker, Status
from database import Database
from settings import SettingsStore
from ui_main import MainWindow
from ui_pages import AppContext, ManualVerifyDialog

app = QApplication.instance() or QApplication([])
QMessageBox.information = staticmethod(lambda *a, **k: None)   # never block headless
QMessageBox.warning = staticmethod(lambda *a, **k: None)
QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.StandardButton.Yes)


def make_ctx(tmp: Path, checker=None) -> AppContext:
    store = SettingsStore(tmp / "settings.json")
    s = store.load()
    s.export_dir = str(tmp / "exports")
    return AppContext(store, s, Database(tmp / "r.db"), checker or AvailabilityChecker())


class UiTests(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.tmp = Path(self.tmpdir.name)
        self.ctx = make_ctx(self.tmp)
        self.win = MainWindow(self.ctx)
        self.win.show()
        self.gen, self.pat, self.res, self.set = (self.win.stack.widget(i) for i in range(4))

    def tearDown(self):
        self.ctx.db.close()
        self.win.close()
        self.tmpdir.cleanup()

    def test_generate_all_modes_into_results(self):
        total = 0
        for mode in ("Letters only", "Numbers and letters", "Letters with underscores",
                     "Letters with periods", "Custom characters"):
            self.gen.mode.setCurrentText(mode)
            self.gen.custom.setText("a-f0-9_.")
            self.gen.count.setCurrentText("50")
            self.gen.generate()
            self.assertEqual(len(self.gen.last_batch), 50)
            total += 50
        self.assertEqual(self.ctx.db.count(), total)
        self.assertEqual(self.ctx.db.counts_by_status()[Status.UNKNOWN], total)
        self.assertEqual(self.res.table.rowCount(), total)
        self.assertIn(str(total), self.res.chips[None].text())

    def test_pattern_and_filter_search(self):
        self.pat.preset.setCurrentText("Period in position 2 (like q.z9)")
        self.pat.count.setCurrentText("50")
        self.pat.generate()
        self.assertEqual(self.res.table.rowCount(), 50)
        self.res.search.setText("q.")
        self.assertTrue(all(self.res.table.item(r, 0).text().startswith("q.") for r in range(self.res.table.rowCount())))
        self.res.search.setText("")
        self.res._set_filter(Status.TAKEN)
        self.assertEqual(self.res.table.rowCount(), 0)

    def test_manual_verification_and_exports(self):
        self.gen.count.setCurrentText("10")
        self.gen.generate()
        dlg = ManualVerifyDialog(self.ctx, self.win)
        self.assertEqual(len(dlg.queue), 10)
        first = dlg.name.text()
        self.assertEqual(QApplication.clipboard().text(), first)  # auto-copy
        for i in range(10):
            dlg.decide(Status.AVAILABLE if i % 2 == 0 else Status.TAKEN)
        self.assertEqual(dlg.name.text(), "Done")
        c = self.ctx.db.counts_by_status()
        self.assertEqual((c[Status.AVAILABLE], c[Status.TAKEN], c[Status.UNKNOWN]), (5, 5, 0))
        self.assertTrue(all(r.source == "manual" for r in self.ctx.db.all()))
        # exports
        self.res.copy_available()
        self.assertEqual(len(QApplication.clipboard().text().split()), 5)
        self.res.export_txt()
        self.res.export_csv()
        files = sorted(p.name for p in (self.tmp / "exports").iterdir())
        self.assertTrue(any(f.startswith("available_") for f in files))
        self.assertTrue(any(f.startswith("results_") for f in files))
        self.gen.save_list()
        self.assertTrue(any(p.name.startswith("generated_") for p in (self.tmp / "exports").iterdir()))
        # delete selected + clear
        self.res.table.selectRow(0)
        self.res.delete_selected()
        self.assertEqual(self.ctx.db.count(), 9)
        self.res.clear()
        self.assertEqual(self.ctx.db.count(), 0)
        self.assertEqual(self.res.table.rowCount(), 0)

    def test_skip_in_manual_dialog_and_empty(self):
        dlg = ManualVerifyDialog(self.ctx, self.win)
        self.assertEqual(dlg.name.text(), "Nothing to verify")
        self.gen.count.setCurrentText("10")
        self.gen.generate()
        dlg = ManualVerifyDialog(self.ctx, self.win)
        dlg.skip()
        self.assertEqual(self.ctx.db.counts_by_status()[Status.UNKNOWN], 10)  # skipping changes nothing

    def test_generator_errors_do_not_crash(self):
        self.gen.prefix.setText("zz")
        self.gen.exclude.setText("z")
        self.gen.generate()          # shows warning (patched), no exception
        self.assertEqual(self.ctx.db.count(), 0)

    def test_auto_check_disabled_by_default(self):
        self.assertFalse(self.gen.auto_btn.isEnabled())
        self.assertIn("unavailable", self.gen.checker_label.text())

    def test_theme_and_settings_persistence(self):
        self.set.theme.setCurrentText("Light")
        self.assertEqual(self.ctx.settings.theme, "light")
        self.assertIn("#f3f4f7", app.styleSheet())
        self.set.count.setCurrentText("500")
        self.set.nodup.setChecked(False)
        self.set.delay.setValue(7.5)
        again = SettingsStore(self.tmp / "settings.json").load()
        self.assertEqual((again.theme, again.generation_count, again.prevent_duplicates, again.request_delay),
                         ("light", 500, False, 7.5))
        self.set.theme.setCurrentText("Dark")
        self.assertIn("#0b0c0f", app.styleSheet())
        self.assertEqual(self.ctx.checker.delay, 7.5)

    def test_worker_with_fake_automatic_provider(self):
        class Fake:
            name, supports_automatic = "fake", True
            def check(self, u, client):
                if u[0] < "m":
                    return ck.make_result(u, Status.TAKEN, "api")
                raise ck.NetworkFailure("down")
        ctx = make_ctx(self.tmp / "w") if (self.tmp / "w").mkdir() is None else None
        ctx.checker = AvailabilityChecker(Fake(), sleep=lambda s: None, delay=1.0)
        win = MainWindow(ctx)
        gen = win.stack.widget(0)
        gen.count.setCurrentText("10")
        gen.generate()
        self.assertTrue(gen.auto_btn.isEnabled())
        loop = QEventLoop()
        gen.run_auto()
        gen.worker.done.connect(loop.quit)
        QTimer.singleShot(8000, loop.quit)
        loop.exec()
        app.processEvents()
        c = ctx.db.counts_by_status()
        self.assertEqual(c[Status.AVAILABLE], 0)  # failures never become AVAILABLE
        self.assertEqual(c[Status.TAKEN] + c[Status.UNKNOWN], 10)
        notes = [r.note for r in ctx.db.all() if r.status is Status.UNKNOWN]
        self.assertTrue(all("failed" in n.lower() for n in notes))
        ctx.db.close()
        win.close()


if __name__ == "__main__":
    unittest.main()
